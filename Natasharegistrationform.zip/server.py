from flask import Flask, render_template, request, redirect, session, flash
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
passwordRegex = re.compile(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$')
app = Flask(__name__)
app.secret_key= 'hello'

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/process', methods=['POST'])
def validation():
    #Checking first name
    if len(request.form['first_name']) < 1:
        flash('*First name cannot be blank\n')
    elif any(char.isdigit() for char in request.form['first_name']) == True:
        flash('*First name cannot have numbers\n')
    else:
        session['first_name'] = request.form['first_name']

    #Checking last name
    if len(request.form['last_name']) < 1:
        flash('*Last name cannot be blank\n')
    elif any(char.isdigit() for char in request.form['last_name']) == True:
        flash('*Last name cannot have numbers\n')
    else:
        session['last_name'] = request.form['last_name']

    #Checking Email
    if len(request.form['email']) < 1:
        flash("*Email cannot be blank!\n")
    elif not EMAIL_REGEX.match(request.form['email']):
        flash("*Invalid Email Address!\n")
    else:
        flash("Success!")
    
    #Checking password
    if len(request.form['password']) < 1:
        flash('*Password cannot be blank\n')
    elif len(request.form['password']) < 8:
        flash('*Password must be greater than 8 characters\n')
    elif not passwordRegex.match(request.form['password']):
        flash('*Password must contain at least one lowercase letter, one uppercase letter, and one digit\n')
    else:
        session['password'] = request.form['password']

    #Checking confirmation password
    if len(request.form['conf_pass']) < 1:
        flash('*Please confirm password\n')
    elif request.form['conf_pass'] != request.form['password']:
        flash('*Passwords do not match!\n')
    else:
        session['conf_pass'] = request.form['conf_pass']
    return redirect('/')

# @app.route('/result', methods=[POST'])
# def results():
# return render_template('results.html')

app.run(debug=True)
